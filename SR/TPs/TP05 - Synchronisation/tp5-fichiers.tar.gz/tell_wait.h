#include "csapp.h"

void init_synchro();

void tell_parent();

void wait_parent();

void tell_child(pid_t p);

void wait_child();

